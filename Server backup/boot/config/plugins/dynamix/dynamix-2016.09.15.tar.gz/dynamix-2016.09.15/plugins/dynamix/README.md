**Dynamix webGui**

The *Dynamix* webGui is the latest iteration of the unRAID Server OS System
Management Utility.  Built upon *Simple Features*, it provides real-time
screen updates, tabbed viewing and many more enhancements.
